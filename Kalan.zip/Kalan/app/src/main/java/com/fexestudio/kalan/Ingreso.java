package com.fexestudio.kalan;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.HashMap;

public class Ingreso extends AppCompatActivity {

    private Button btnJIngreso;
    private TextView txtJUsuario, txtJContra;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//Evitar Rotacion de pantalla
        setContentView(R.layout.activity_ingreso);
        btnJIngreso = (Button) findViewById(R.id.btn1ingreso);
        txtJUsuario = (TextView) findViewById(R.id.txt1Usuario);
        txtJContra = (TextView) findViewById(R.id.txt1Contra);

        btnJIngreso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap postData = new HashMap();
                String username = txtJUsuario.getText().toString();
                String password = txtJContra.getText().toString();

                postData.put("txtUsername", username);
                postData.put("txtPassword", password);

                PostResponseAsyncTask task1 = new PostResponseAsyncTask(Ingreso.this, postData, new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {

                        Log.d("Login: ", s);
                        if (s.contains("success")) {
                            Toast.makeText(Ingreso.this, "INGRESO SATISFACTORIO", Toast.LENGTH_LONG).show();
                           /* Intent in = new Intent(Ingreso.this, Inicio.class);
                            startActivity(in);*/
                        } else {
                            Toast.makeText(Ingreso.this, "ERROR: INTENTE DE NUEVO", Toast.LENGTH_LONG).show();
                        }
                        //
                    }
                });
                task1.execute("http://pasaelpackpapu.com/vamoayudar/index.php");
            }
        });
    }
}
