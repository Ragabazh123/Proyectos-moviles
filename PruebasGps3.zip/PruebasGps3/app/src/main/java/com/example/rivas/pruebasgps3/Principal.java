package com.example.rivas.pruebasgps3;

import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Principal extends AppCompatActivity {

    private Button btnJObtenCoordenadas;
    private Button btnJAbreMapa;
    ServicioCoordenadas servicio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        btnJObtenCoordenadas = (Button)findViewById(R.id.btnObtenCoordenadas);
        btnJAbreMapa = (Button)findViewById(R.id.btnMuestraMapa);

        servicio = new ServicioCoordenadas(getApplicationContext());

        btnJObtenCoordenadas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                servicio.setView(findViewById(R.id.lblCoordenadas));
            }
        });

        btnJAbreMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in1 = new Intent(Principal.this, Mapa.class);
                startActivity(in1);
            }
        });

    }


}
