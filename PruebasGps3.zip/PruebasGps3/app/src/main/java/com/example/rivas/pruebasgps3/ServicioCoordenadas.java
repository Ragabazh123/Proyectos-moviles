package com.example.rivas.pruebasgps3;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Rivas on 18/08/2016.
 */
public class ServicioCoordenadas extends Service implements LocationListener {
    @Nullable
    private final Context ctx;
    private double latitud;
    private double longitud;
    private Location locacion;
    private boolean gpsActivo;
    private TextView texto;
    private LocationManager locationManager;
    private int aux = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public ServicioCoordenadas() {
        super();
        this.ctx = this.getApplicationContext();
        getLocation();
    }

    public ServicioCoordenadas(Context c) {
        super();
        this.ctx = c;
        getLocation();
    }


    public double getLat(){
        return latitud;
    }
    public double getLon(){
        return longitud;
    }

    public void setView(View v) {
        getLocation();
        aux++;

        texto = (TextView) v;
        texto.setText("Coordenadas: " + latitud + ", " + longitud+",Peticion: "+aux);
    }

    public void getLocation() {
        try {
            locationManager = (LocationManager) this.ctx.getSystemService(LOCATION_SERVICE);
            gpsActivo = locationManager.isProviderEnabled(locationManager.GPS_PROVIDER);
        } catch (Exception e) {
        }
        if (gpsActivo) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    return;
                }
                else{
                    locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 1000 * 10, 10, this);
                    locacion = locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
                }
            }else{
                locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 1000 * 10, 10, this);
                locacion = locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
            }
            latitud = locacion.getLatitude();
            longitud = locacion.getLongitude();
        }
    }
    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
