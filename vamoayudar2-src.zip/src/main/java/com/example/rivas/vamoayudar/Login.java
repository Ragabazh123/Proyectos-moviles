package com.example.rivas.vamoayudar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.HashMap;

public class Login extends AppCompatActivity {
    private Button btnlogin;
    private Button btnregistro;
    private EditText etuser, etpassword;
    final String LOG = "Login";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnlogin = (Button)findViewById(R.id.btnlogin);
        btnregistro = (Button)findViewById(R.id.btnregistrar);
        etuser = (EditText)findViewById(R.id.etuser);
        etpassword = (EditText)findViewById(R.id.etpass);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap postData = new HashMap();
                String username = etuser.getText().toString();
                String password = etpassword.getText().toString();

                postData.put("txtUsername",username);
                postData.put("txtPassword",password);

                PostResponseAsyncTask task1 = new PostResponseAsyncTask(Login.this, postData, new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {

                        Log.d(LOG, s);
                        if(s.contains("success")){
                            Toast.makeText(Login.this, "INGRESO SATISFACTORIO", Toast.LENGTH_LONG).show();
                            Intent in = new Intent(Login.this, Menu_Principal.class);
                            startActivity(in);
                        }
                        else {
                            Toast.makeText(Login.this, "ERROR: INTENTE DE NUEVO", Toast.LENGTH_LONG).show();
                        }
                        //
                    }
                });
                task1.execute("http://pasaelpackpapu.com/vamoayudar/index.php");
            }
        });
        btnregistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in2 = new Intent(Login.this, Registro.class);
                startActivity(in2);
            }
        });


    }

    public void registro(View v){
        Intent registro = new Intent(Login.this, Registro.class);
        startActivity(registro);



    }
    public void OnClickMenu_Principal(){

    }

}
