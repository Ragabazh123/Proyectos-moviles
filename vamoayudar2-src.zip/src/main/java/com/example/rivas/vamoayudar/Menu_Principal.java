package com.example.rivas.vamoayudar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;

public class Menu_Principal extends AppCompatActivity {
    private ImageButton emergencia1;
    private ImageButton emergencia2;
    private ImageButton emergencia3;
    private ImageButton emergencia4;
    private ImageButton emergencia5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__principal);

        emergencia1 = (ImageButton)findViewById(R.id.imageButton);
        emergencia2 = (ImageButton)findViewById(R.id.imageButton3);
        emergencia3 = (ImageButton)findViewById(R.id.imageButton2);
        emergencia4 = (ImageButton)findViewById(R.id.imageButton5);
        emergencia5 = (ImageButton)findViewById(R.id.imageButton7);

        emergencia1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emergencia1 = new Intent(Menu_Principal.this, EnviaNotificacion.class);
                emergencia1.putExtra("emergencia","asfixia");
                startActivity(emergencia1);

            }
        });
        emergencia2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emergencia2 = new Intent(Menu_Principal.this, EnviaNotificacion.class);
                emergencia2.putExtra("emergencia","desmayo");
                startActivity(emergencia2);

            }
        });
        emergencia3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emergencia3 = new Intent(Menu_Principal.this, EnviaNotificacion.class);
                emergencia3.putExtra("emergencia","fractura");
                startActivity(emergencia3);

            }
        });
        emergencia4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emergencia4 = new Intent(Menu_Principal.this, EnviaNotificacion.class);
                emergencia4.putExtra("emergencia","electrocutado");
                startActivity(emergencia4);

            }
        });
        emergencia5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emergencia5 = new Intent(Menu_Principal.this, EnviaNotificacion.class);
                emergencia5.putExtra("emergencia","atropeyado");
                startActivity(emergencia5);

            }
        });
    }
}
