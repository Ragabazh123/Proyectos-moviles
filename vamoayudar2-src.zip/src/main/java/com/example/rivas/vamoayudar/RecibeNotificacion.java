package com.example.rivas.vamoayudar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RecibeNotificacion extends AppCompatActivity {
    private Button principal;
    private Button mapa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recibe_notificacion);

        principal = (Button)findViewById(R.id.button13);
        mapa = (Button)findViewById(R.id.button14);

        principal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent principal = new Intent(RecibeNotificacion.this, Menu_Principal.class);
                startActivity(principal);
            }
        });

        mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mapa = new Intent(RecibeNotificacion.this, Localizacion.class);
                startActivity(mapa);
            }
        });


    }
}
