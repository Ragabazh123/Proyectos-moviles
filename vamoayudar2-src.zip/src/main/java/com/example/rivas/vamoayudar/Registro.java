package com.example.rivas.vamoayudar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.HashMap;

public class Registro extends AppCompatActivity {

    Button atras;
    Button siguiente;
    EditText eNombre, eApellidoP, eApellidoM, eEdad, eTel, eIFE, eCorreo;
    final String LOG = "Registro";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        atras = (Button)findViewById(R.id.btnatrasR);
        siguiente = (Button)findViewById(R.id.btnsiguienteR);
        eNombre = (EditText)findViewById(R.id.etnombreR);
        eApellidoP = (EditText)findViewById(R.id.etapellidoPR);
        eApellidoM = (EditText)findViewById(R.id.etapellidoMR);
        eEdad = (EditText)findViewById(R.id.etedadR);
        eIFE = (EditText)findViewById(R.id.etifeR);
        eCorreo = (EditText)findViewById(R.id.etcorreoR);
        eTel = (EditText)findViewById(R.id.ettelR);




        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atras = new Intent(Registro.this, Login.class);
                startActivity(atras);
            }
        });
        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap postData = new HashMap();
                String nombre = eNombre.getText().toString();
                String apellidoP = eApellidoP.getText().toString();
                String apellidoM = eApellidoM.getText().toString();
                String edad = eEdad.getText().toString();
                final String ife = eIFE.getText().toString();
                String correo = eCorreo.getText().toString();
                String tel = eTel.getText().toString();
                String mobile = "android";

                postData.put("txtNombre",nombre);
                postData.put("txtApellidoP",apellidoP);
                postData.put("txtApellidoM",apellidoM);
                postData.put("txtEdad",edad);
                postData.put("txtIDIFE",ife);
                postData.put("txtCorreo",correo);
                postData.put("txtTelefono",tel);
                postData.put("mobile",mobile);

                PostResponseAsyncTask task1 = new PostResponseAsyncTask(Registro.this, postData, new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {

                        Log.d(LOG, s);
                        if(s.contains("success")){
                            Toast.makeText(Registro.this, "INSERTADO SATISFACTORIAMENTE", Toast.LENGTH_LONG).show();
                            Intent in = new Intent(Registro.this, Registro2.class);
                            in.putExtra("IFE", ife);
                            startActivity(in);
                        }
                        else {
                            Toast.makeText(Registro.this, "ERROR: INTENTE DE NUEVO", Toast.LENGTH_LONG).show();
                        }
                        //
                    }
                });
                task1.execute("http://pasaelpackpapu.com/vamoayudar/insert.php");

            }
        });


    }
}
