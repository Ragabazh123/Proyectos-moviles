package com.example.rivas.vamoayudar;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.io.File;
import java.util.HashMap;

public class Registro2 extends AppCompatActivity {

    private Button cargar;
    private Button atras;
    private Button siguiente;
    private EditText txtUser, txtPass;

    private String APP_DIRECTORY = "VamoAyudar/";
    private String MEDIA_DIRECTORY = APP_DIRECTORY + "media";
    private String TEMPORAL_PICTURE_NAME = "temporal.jpg";

    private final int PHOTO_CODE = 100;
    private final int SELECT_PICTURE = 200;

    private ImageView imageView;
    final String LOG = "Registro2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro2);

        cargar = (Button)findViewById(R.id.btnImagen);
        atras = (Button)findViewById(R.id.btnAtrasR2);
        siguiente = (Button)findViewById(R.id.btnSiguienteR2);
        imageView = (ImageView)findViewById(R.id.imageViewR2);
        txtUser = (EditText)findViewById(R.id.etUserR2);
        txtPass = (EditText)findViewById(R.id.etPassR2);


        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atras = new Intent(Registro2.this, Registro.class);
                startActivity(atras);
            }
        });
        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HashMap postData = new HashMap();
                String imagen = "imagen-android.jpg";
                String user = txtUser.getText().toString();
                String pass = txtPass.getText().toString();
                String mobile = "android";
                final String ife = getIntent().getExtras().getString("IFE");
                postData.put("txtImagen",imagen);
                postData.put("txtUser",user);
                postData.put("txtPass",pass);
                postData.put("mobile",mobile);
                postData.put("txtIDIFE",ife);

                PostResponseAsyncTask task1 = new PostResponseAsyncTask(Registro2.this, postData, new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {

                        Log.d(LOG, s);
                        if(s.contains("success")){
                            Toast.makeText(Registro2.this, "INSERTADO SATISFACTORIAMENTE", Toast.LENGTH_LONG).show();
                            Intent in = new Intent(Registro2.this, Registro3.class);
                            in.putExtra("IFE", ife);
                            startActivity(in);
                        }
                        else {
                            Toast.makeText(Registro2.this, "ERROR: INTENTE DE NUEVO", Toast.LENGTH_LONG).show();
                        }
                        //
                    }
                });
                task1.execute("http://pasaelpackpapu.com/vamoayudar/insert2.php");


            }
        });

        cargar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final CharSequence[] options = {"Tomar foto", "Elegir de galeria", "Cancelar"};
                final AlertDialog.Builder builder = new AlertDialog.Builder(Registro2.this);
                builder.setTitle("Elige una opción :D");
                builder.setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int seleccion) {
                        if (options[seleccion] == "Tomar foto") {
                            openCamera();
                        } else if (options[seleccion] == "Elegir de galeria") {
                            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            intent.setType("image/*");
                            startActivityForResult(intent.createChooser(intent, "Selecciona app de imagen"), SELECT_PICTURE);
                        } else if (options[seleccion] == "Cancelar") {
                            dialog.dismiss();
                        }
                    }
                });
                builder.show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode){
            case PHOTO_CODE:
                if(resultCode == RESULT_OK){
                    String dir = Environment.getExternalStorageDirectory() + File.separator + MEDIA_DIRECTORY + File.separator + TEMPORAL_PICTURE_NAME;
                    decodeBitmap(dir);

                }
                break;
            case SELECT_PICTURE:
                if(resultCode == RESULT_OK){
                    Uri path = data.getData();
                    imageView.setImageURI(path);

                }
                break;
        }
    }

    private void decodeBitmap(String dir) {
        Bitmap bitmap;
        bitmap = BitmapFactory.decodeFile(dir);

        imageView.setImageBitmap(bitmap);
    }

    private void openCamera() {
        File file = new File(Environment.getExternalStorageDirectory(), MEDIA_DIRECTORY);
        file.mkdirs();

        String path = Environment.getExternalStorageDirectory() + File.separator + MEDIA_DIRECTORY + File.separator + TEMPORAL_PICTURE_NAME;

        File newFile = new File(path);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(newFile));
        startActivityForResult(intent, PHOTO_CODE);


    }


}
