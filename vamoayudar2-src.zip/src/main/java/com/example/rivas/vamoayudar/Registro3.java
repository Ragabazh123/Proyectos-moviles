package com.example.rivas.vamoayudar;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import java.util.HashMap;

public class Registro3 extends AppCompatActivity {
    private Button siguiente;
    final String LOG = "Registro3";

    private CheckBox cb1, cb2, cb3, cb4, cb5, cb6, cb7, cb8, cb9, cb10, cb11, cb12;
    /*private CheckBox cb[] = new CheckBox[20];*/

    private String skills = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro3);
        siguiente = (Button)findViewById(R.id.btnSiguienteR3);
        cb1 = (CheckBox)findViewById(R.id.cb1insolacion);
        cb2 = (CheckBox)findViewById(R.id.cb2quemaduras);
        cb3 = (CheckBox)findViewById(R.id.cb3rcp);
        cb4 = (CheckBox)findViewById(R.id.cb4rbb);
        cb5 = (CheckBox)findViewById(R.id.cb5epilepsia);
        cb6 = (CheckBox)findViewById(R.id.cb6asfixia);
        cb7 = (CheckBox)findViewById(R.id.cb7infartos);
        cb8 = (CheckBox)findViewById(R.id.cb8hipotermia);
        cb9 = (CheckBox)findViewById(R.id.cb9contusiones);
        cb10 = (CheckBox)findViewById(R.id.cb10fracturas);
        cb11 = (CheckBox)findViewById(R.id.cb11intoxicacion);
        cb12 = (CheckBox)findViewById(R.id.cb12sobredosis);

       /* cb[0] = (CheckBox)findViewById(R.id.cb1insolacion);
        cb[1] = (CheckBox)findViewById(R.id.cb2quemaduras);
        cb[2] = (CheckBox)findViewById(R.id.cb3rcp);
        cb[3] = (CheckBox)findViewById(R.id.cb4rbb);
        cb[4] = (CheckBox)findViewById(R.id.cb5epilepsia);
        cb[5] = (CheckBox)findViewById(R.id.cb6asfixia);
        cb[6] = (CheckBox)findViewById(R.id.cb7infartos);
        cb[7] = (CheckBox)findViewById(R.id.cb8hipotermia);
        cb[8] = (CheckBox)findViewById(R.id.cb9contusiones);
        cb[9] = (CheckBox)findViewById(R.id.cb10fracturas);
        cb[10] = (CheckBox)findViewById(R.id.cb11intoxicacion);
        cb[11] = (CheckBox)findViewById(R.id.cb12sobredosis);
        int i = 0;
        while(i < 12){
            if (cb[i].isChecked() == true){
                skills = skills + 1;
            }
            else{
                skills = skills + 0;
            }

        }*/


        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap postData = new HashMap();
                String mobile = "android";
                String ife = getIntent().getExtras().getString("IFE");

                if(cb1.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb2.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb3.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb4.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb5.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb6.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb7.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb8.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb9.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb10.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb11.isChecked())skills = skills + 1;
                else skills = skills + 0;
                if(cb12.isChecked())skills = skills + 1;
                else skills = skills + 0;

                skills = skills + "00000000";

                postData.put("txtSkills", skills);
                postData.put("mobile", mobile);
                postData.put("txtIDIFE", ife);

                PostResponseAsyncTask task1 = new PostResponseAsyncTask(Registro3.this, postData, new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {

                        Log.d(LOG, s);
                        if (s.contains("success")) {
                            Toast.makeText(Registro3.this, "INSERTADO SATISFACTORIAMENTE", Toast.LENGTH_LONG).show();
                            Intent in = new Intent(Registro3.this, Menu_Principal.class);
                            startActivity(in);
                        } else {
                            Toast.makeText(Registro3.this, "ERROR: INTENTE DE NUEVO", Toast.LENGTH_LONG).show();
                        }
                        //
                    }
                });
                task1.execute("http://pasaelpackpapu.com/vamoayudar/insert3.php");

            }
        });


    }
}
